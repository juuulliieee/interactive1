$(document).ready(function(){
	
	$('body').keypress(function( event ) {
		alert('r is '+event.which+', g is '+event.which+' divided by 2, b is '+event.which+' times 1.5');
		$('h1').css('color', 'rgb('+event.which+', '+event.which/2+', '+event.which*1.5+')');
		$('h1').html('the color is rgb('+event.which+', '+event.which/2+', '+event.which*1.5+')');
	});

});