$(document).ready(function(){
	
	$('#web-1').mouseover(function(){
		// change the 'attr' or attribute of #video-background's 'src' or source on click
		$('.vbg1').fadeIn("");
		$('.vbg1')[0].play();
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});

	$('#web-1').mouseleave(function(){

		
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg1').fadeOut("");
		$('.vbg1')[0].pasue();
		

	});

	$('#web-2').mouseover(function(){

		$('.vbg2').fadeIn("");
		$('.vbg2')[0].play();
		$("#web-1").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});

	$('#web-2').mouseleave(function(){
		
		$('.vbg2').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg2')[0].pasue();

	});



	$('#web-3').mouseover(function(){
		
		$('.vbg3').fadeIn("");
		$('.vbg3')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});

	$('#web-3').mouseleave(function(){
		
		$('.vbg3').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg3')[0].pasue();

	});

	$('#web-4').mouseover(function(){
		
		$('.vbg4').fadeIn("");
		$('.vbg4')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});


	$('#web-4').mouseleave(function(){
		
		$('.vbg4').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg4')[0].pasue();

	});

	$('#web-5').mouseover(function(){

		$('.vbg5').fadeIn("");
		$('.vbg5')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");
	});


	$('#web-5').mouseleave(function(){
		
		$('.vbg5').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg5')[0].pasue();

	});

	$('#web-6').mouseover(function(){

		$('.vbg6').fadeIn("");
		$('.vbg6')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");
		
	});


	$('#web-6').mouseleave(function(){
		
		$('.vbg6').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg6')[0].pasue();

	});

	$('#web-7').mouseover(function(){
		
		$('.vbg7').fadeIn("");
		$('.vbg7')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});

	$('#web-7').mouseleave(function(){
		
		$('.vbg7').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg7')[0].pasue();

	});

	$('#web-8').mouseover(function(){
		
		$('.vbg8').fadeIn("");
		$('.vbg8')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-9").fadeOut("");
		$("#web-10").fadeOut("");

	});


	$('#web-8').mouseleave(function(){
		
		$('.vbg8').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-9").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg8')[0].pasue();

	});

	$('#web-9').mouseover(function(){
		
		$('.vbg9').fadeIn("");
		$('.vbg9')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-10").fadeOut("");

	});

	$('#web-9').mouseleave(function(){
		
		$('.vbg9').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-10").fadeIn("");
		$('.vbg9')[0].pasue();

	});

	$('#web-10').mouseover(function(){
		
		$('.vbg10').fadeIn("");
		$('.vbg10')[0].play();
		$("#web-1").fadeOut("");
		$("#web-2").fadeOut("");
		$("#web-3").fadeOut("");
		$("#web-4").fadeOut("");
		$("#web-5").fadeOut("");
		$("#web-6").fadeOut("");
		$("#web-7").fadeOut("");
		$("#web-8").fadeOut("");
		$("#web-9").fadeOut("");

	});

	$('#web-10').mouseleave(function(){
		
		$('.vbg10').fadeOut("");
		$("#web-1").fadeIn("");
		$("#web-2").fadeIn("");
		$("#web-3").fadeIn("");
		$("#web-4").fadeIn("");
		$("#web-5").fadeIn("");
		$("#web-6").fadeIn("");
		$("#web-7").fadeIn("");
		$("#web-8").fadeIn("");
		$("#web-9").fadeIn("");
		$('.vbg10')[0].pasue();

	});



















});