$(document).ready(function(){
	
	$('body').click(function(){
		
		$redValue = Math.floor(Math.random()*255);
		$greenValue = Math.floor(Math.random()*255);
		$blueValue = Math.floor(Math.random()*255);	
		
		$('body').css(
			'background', 'rgba('+$redValue+','+$blueValue+','+$greenValue+', 1)'
		);
	});
	

});