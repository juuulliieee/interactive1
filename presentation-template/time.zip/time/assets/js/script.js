$(document).ready(function(){
	
	setInterval(function(){
		$('body').append('<img src="http://i.imgur.com/WfROBmY.jpg" />');
	},1000);
	

});